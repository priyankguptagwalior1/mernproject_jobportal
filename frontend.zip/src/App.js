import "bootstrap/dist/css/bootstrap.min.css";
import AdminHome from "./layouts/admin/AdminHome";
import EmployerHome from "./layouts/employers/EmployerHome";
import GuestUserHome from "./layouts/guestusers/GuestUserHome";
// import RegUserHome from "./layouts/regusers/RegUserHome";
import ShowData from "./components/ShowData";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import EmployerLogin from "./components/employers/EmployerLogin";
import EmployerReg from "./components/employers/EmployerReg";
import UserLogin from "./components/regusers/UserLogin";
import UserReg from "./components/guestusers/UserReg";
import Home from "./components/Home";
import About from "./components/About";
import Posts from "./components/Posts";
import NewPost from "./components/NewPost";
import Post from "./components/Post";
import AdminLogin from "./components/admin/AdminLogin";
import AdminDashboard from "./layouts/admin/AdminDashboard";
import EmployerUpdate from "./components/admin/EmployerUpdate";
import AdminLogout from "./components/admin/AdminLogout";
import EmployerDashboard from "./layouts/employers/EmployerDashboard";
function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/user" element={<GuestUserHome />}>
            <Route path="login" element={<UserLogin />} />
            <Route path="reg" element={<UserReg />} />
          </Route>
          <Route path="/employer" element={<EmployerHome />}>
            <Route path="login" element={<EmployerLogin />} />
            <Route path="reg" element={<EmployerReg />} />
          </Route>
          <Route path="/employerdashboard" element={<EmployerDashboard />} />
          <Route path="/admin" element={<AdminHome />}>
            <Route path="login" element={<AdminLogin />} />
            <Route path="logout" element={<AdminLogout />} />
            <Route path="employerupdate" element={<EmployerUpdate />} />
          </Route>
          <Route path="/admindashboard" element={<AdminDashboard />} />
        </Routes>
      </BrowserRouter>

      {/* <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="about" element={<About />} />
          <Route path="posts" element={<Posts />}>
            <Route path="new" element={<NewPost />} />
            <Route path=":postId" element={<Post />} />
          </Route>
        </Routes>
      </BrowserRouter> */}
    </>
  );
}

export default App;
