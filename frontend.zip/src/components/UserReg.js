import axios from "axios";
import React, { useState } from "react";

const UserReg = () => {
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [userMobile, setUserMobile] = useState("");
  const [userPassword, setUserPassword] = useState("");
  const [userRPassword, setUserRPassword] = useState("");
  const InsertData = async () => {
    console.log(userName, userEmail, userMobile, userPassword, userRPassword);
    const sendData = {
      userName,
      userEmail,
      userMobile,
      userPassword,
      userRPassword,
    };
    const udata = await axios.post(
      "http://localhost:8000/api/v1/userreg/register",
      sendData
    );
  };
  return (
    <div>
      <input
        type="text"
        value={userName}
        onChange={(e) => setUserName(e.target.value)}
      />
      <br />
      <input
        type="email"
        value={userEmail}
        onChange={(e) => setUserEmail(e.target.value)}
      />
      <br />
      <input
        type="number"
        value={userMobile}
        onChange={(e) => setUserMobile(e.target.value)}
      />
      <br />
      <input
        type="password"
        value={userPassword}
        onChange={(e) => setUserPassword(e.target.value)}
      />
      <br />
      <input
        type="password"
        value={userRPassword}
        onChange={(e) => setUserRPassword(e.target.value)}
      />
      <br />
      <button onClick={() => InsertData()}>Insert</button>
    </div>
  );
};
export default UserReg;
