import React from "react";

const Post = () => {
  return <div>Hello Post</div>;
};

export default Post;
