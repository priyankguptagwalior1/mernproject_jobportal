import axios from "axios";
import React, { useEffect } from "react";

const ShowCompanies = () => {
  const ShowCompaniesData = async () => {
    try {
      console.log("Test ShowCompanies");
      const CompaniesAllData = await axios.get(
        "http://localhost:8000/api/v1/employer/showallcompanies"
      );
      console.log(CompaniesAllData);
    } catch (err) {
      console.err("Error...", err);
    }
  };
  useEffect(() => {
    ShowCompaniesData();
  }, []);

  return <div>ShowCompanies data</div>;
};

export default ShowCompanies;
