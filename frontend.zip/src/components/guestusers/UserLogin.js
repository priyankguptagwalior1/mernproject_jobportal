import axios from "axios";
import React, { useState } from "react";
import {
  MDBContainer,
  MDBInput,
  MDBCheckbox,
  MDBBtn,
  MDBIcon,
} from "mdb-react-ui-kit";

function UserLogin() {
  const [userEmail, setUserEmail] = useState("");
  const [userPassword, setUserPassword] = useState("");
  const UserLoginBtn = async () => {
    console.log(userEmail, userPassword);
    const sendData = {
      userEmail,
      userPassword,
    };
    const udata = await axios.post(
      "http://localhost:8000/api/v1/userreg/login",
      sendData
    );
    console.log(udata);
  };

  return (
    <MDBContainer className="p-3 my-5 d-flex flex-column w-50">
      <MDBInput
        wrapperClass="mb-4"
        label="Email address"
        id="form1"
        type="email"
        value={userEmail}
        onChange={(e) => setUserEmail(e.target.value)}
      />
      <MDBInput
        wrapperClass="mb-4"
        label="Password"
        id="form2"
        type="password"
        value={userPassword}
        onChange={(e) => setUserPassword(e.target.value)}
      />

      <MDBBtn className="mb-4" onClick={() => UserLoginBtn()}>
        User Sign in
      </MDBBtn>
    </MDBContainer>
  );
}

export default UserLogin;
