import axios from "axios";
import React, { useState } from "react";
import { MDBContainer, MDBInput, MDBBtn } from "mdb-react-ui-kit";

function UserReg() {
  const [userName, setUserName] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [userMobile, setUserMobile] = useState("");
  const [userPassword, setUserPassword] = useState("");
  const [userRPassword, setUserRPassword] = useState("");
  const InsertData = async () => {
    console.log(userName, userEmail, userMobile, userPassword, userRPassword);
    const sendData = {
      userName,
      userEmail,
      userMobile,
      userPassword,
      userRPassword,
    };
    const udata = await axios.post(
      "http://localhost:8000/api/v1/userreg/register",
      sendData
    );
    console.log(udata);
  };

  return (
    <MDBContainer className="p-3 my-5 d-flex flex-column w-50">
      <MDBInput
        wrapperClass="mb-4"
        label="User Name"
        id="form1"
        type="text"
        value={userName}
        onChange={(e) => setUserName(e.target.value)}
      />
      <MDBInput
        wrapperClass="mb-4"
        label="User Email"
        id="form2"
        type="email"
        value={userEmail}
        onChange={(e) => setUserEmail(e.target.value)}
      />
      <MDBInput
        wrapperClass="mb-4"
        label="User Number"
        id="form3"
        type="number"
        value={userMobile}
        onChange={(e) => setUserMobile(e.target.value)}
      />
      <MDBInput
        wrapperClass="mb-4"
        label="User Password"
        id="form4"
        type="password"
        value={userPassword}
        onChange={(e) => setUserPassword(e.target.value)}
      />
      <MDBInput
        wrapperClass="mb-4"
        label="User Re Password"
        id="form5"
        type="password"
        value={userRPassword}
        onChange={(e) => setUserRPassword(e.target.value)}
      />

      <MDBBtn className="mb-4" onClick={() => InsertData()}>
        User Sign Up
      </MDBBtn>
    </MDBContainer>
  );
}

export default UserReg;
