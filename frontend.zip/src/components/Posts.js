import React from "react";
import { Outlet } from "react-router-dom";

const Posts = () => {
  return (
    <div>
      Hello Posts dfas dfasd fas
      <Outlet /> df asdf as d f
    </div>
  );
};

export default Posts;
