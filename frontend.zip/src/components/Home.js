import React from "react";

const Home = () => {
  return <div>Hello Home</div>;
};

export default Home;
