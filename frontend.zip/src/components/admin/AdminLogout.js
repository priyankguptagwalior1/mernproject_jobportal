import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
const AdminLogout = () => {
  const navigate = useNavigate();

  useEffect(() => {
    localStorage.clear();
    navigate("/admin/login");
  }, []);
  return <div>hello logout page</div>;
};

export default AdminLogout;
