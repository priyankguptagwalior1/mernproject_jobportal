import axios, { all } from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const ShowEmployers = () => {
  const [allEmployersData, setAllEmployersData] = useState({});
  const showAllEmployers = async () => {
    try {
      const allData = await axios.get(
        "http://localhost:8000/api/v1/admin/employerdisplay"
      );
      console.log(allData);
      setAllEmployersData(allData);
    } catch (err) {
      console.log(err);
    }
  };
  useEffect(() => {
    showAllEmployers();
  }, []);
  return (
    <div className="container-fluid">
      <center>
        <h1>show all employers</h1>
        <table class="table table-striped">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">ID</th>
              <th scope="col">Name</th>
              <th scope="col">Email-ID</th>
              <th scope="col">Mobile</th>
              <th scope="col">Website</th>
              <th scope="col">Status</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody></tbody>

          {allEmployersData &&
            allEmployersData.data &&
            allEmployersData.data.employerData &&
            allEmployersData.data.employerData.map((data, index) => (
              <>
                <tr>
                  <td scope="row">{index + 1}</td>
                  <td>{data._id}</td>
                  <td>{data.employerName}</td>
                  <td>{data.employerEmail}</td>
                  <td>{data.employerMobile}</td>
                  <td>{data.employerWebsite}</td>
                  <td
                    style={{
                      color:
                        data.employerStatus === "Active" ? `green` : `orange`,
                    }}
                  >
                    {data.employerStatus}
                  </td>
                  <td>
                    <Link to={`/admin/employerupdate/${data._id}`}>
                      Click me
                    </Link>
                  </td>
                </tr>
              </>
            ))}
        </table>
      </center>
    </div>
  );
};

export default ShowEmployers;
