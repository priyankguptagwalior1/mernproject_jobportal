import React, { useState } from "react";
import {
  MDBContainer,
  MDBInput,
  MDBCheckbox,
  MDBBtn,
  MDBIcon,
} from "mdb-react-ui-kit";
import axios from "axios";
import { useNavigate } from "react-router-dom";
function AdminLogin() {
  const [adminLoginId, setAdminLoginId] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [msg, setMsg] = useState("");
  const navigate = useNavigate();
  const ChkLogin = async () => {
    try {
      const sendData = {
        adminLoginId,
        adminPassword,
      };
      const udata = await axios.post(
        "http://localhost:8000/api/v1/admin/login",
        sendData
      );
      console.log("DATA>>>", udata);
      localStorage.setItem("token", udata.data.adminData1.token);
      clearData();
      setMsg("done");
      if (udata.data.status === "success") {
        navigate("/admindashboard");
      } else {
        setMsg("fail");
      }
    } catch (err) {
      setMsg(`ERROR: ${err}`);
      console.log(err);
    }
  };
  const clearData = () => {
    setAdminLoginId("");
    setAdminPassword("");
  };

  return (
    <MDBContainer className="p-3 my-5 d-flex flex-column w-50">
      <MDBInput
        wrapperClass="mb-4"
        label="Email address"
        id="form1"
        type="email"
        value={adminLoginId}
        onChange={(e) => setAdminLoginId(e.target.value)}
      />
      <MDBInput
        wrapperClass="mb-4"
        label="Password"
        id="form2"
        type="password"
        value={adminPassword}
        onChange={(e) => setAdminPassword(e.target.value)}
      />
      <MDBBtn className="mb-4" onClick={ChkLogin}>
        Admin Sign in
      </MDBBtn>
    </MDBContainer>
  );
}

export default AdminLogin;
