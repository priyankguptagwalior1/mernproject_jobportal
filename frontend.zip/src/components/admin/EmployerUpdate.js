import React from "react";

const EmployerUpdate = async (req, res) => {
  console.log("REQ: ", req);
  console.log("RES: ", res);
  console.log("RES: ", res.params);
  return <div>employer update component</div>;
};

export default EmployerUpdate;
