import React from "react";

const About = () => {
  return <div>Hello About</div>;
};

export default About;
