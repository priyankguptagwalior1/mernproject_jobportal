import axios from "axios";
import React, { useEffect, useState } from "react";

const ShowData = () => {
  const [userAllData, setUserAllData] = useState([]);
  const getUserData = async () => {
    const udata = await axios.get(
      "http://localhost:8000/api/v1/userreg/display"
    );
    setUserAllData(udata.data.userData);
    console.log(udata.data.userData);
  };
  useEffect(() => {
    getUserData();
  }, []);
  return (
    <div>
      <h1>USER DATA</h1>
      <table>
        <caption>USER DATA</caption>
        {userAllData.map((dt, key) => {
          return (
            <>
              <tr>
                <td>{key + 1}</td>
                <td>{dt._id}</td>
                <td>{dt.userName}</td>
                <td>{dt.userEmail}</td>
                <td>{dt.userMobile}</td>
                <td>{dt.userPassword}</td>
                <td>{dt.userStatus}</td>
              </tr>
            </>
          );
        })}
      </table>
    </div>
  );
};

export default ShowData;
