import React from "react";

const NewPost = () => {
  return <div>Hello New Post</div>;
};

export default NewPost;
