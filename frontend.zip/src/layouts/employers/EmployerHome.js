import React from "react";
import Header from "../../components/common/Header";
import Footer from "../../components/common/Footer";
import EmployerLogin from "../../components/employers/EmployerLogin";
import { Link, Outlet, Route, Routes } from "react-router-dom";
import EmployerReg from "../../components/employers/EmployerReg";
const EmployerHome = () => {
  const Links = [
    { link: "/employer", linkdis: "Home" },
    { link: "/employer/login", linkdis: "Employer Login" },
    { link: "/employer/reg", linkdis: "Employer Reg" },
    { link: "/user", linkdis: "User" },
    { link: "/admin", linkdis: "Admin" },
  ];

  return (
    <>
      <Header Links={Links} />
      <Outlet />
      <Footer />
      <br />
    </>
  );
};

export default EmployerHome;
