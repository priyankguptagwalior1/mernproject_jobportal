import React from "react";
import Header from "../../components/common/Header";
import { Outlet } from "react-router-dom";
import Footer from "../../components/common/Footer";

const EmployerDashboard = () => {
  const Links = [
    { link: "/jobpost", linkdis: "Job Post" },
    { link: "/showmypost", linkdis: "Show My Post" },
    { link: "/showallresumes", linkdis: "Show All Resumes" },
  ];
  return (
    <div>
      <Header Links={Links} />
      <Outlet />
      <Footer />
    </div>
  );
};

export default EmployerDashboard;
