import React from "react";
import Header from "../../components/common/Header";
import Footer from "../../components/common/Footer";
import UserLogin from "../../components/regusers/UserLogin";

const RegUserHome = () => {
  const Links = [
    { link: "#", linkdis: "Home" },
    { link: "#", linkdis: "My Profile" },
    { link: "#", linkdis: "Applied Jobs" },
    { link: "#", linkdis: "Search Jobs" },
    { link: "#", linkdis: "Upload Resume" },
  ];

  return (
    <div>
      RegUserHome Page
      <Header Links={Links} />
      {/* <UserLogin /> */}
      <Footer />
      <br />
    </div>
  );
};

export default RegUserHome;
