import React from "react";
import Header from "../../components/common/Header";
import Footer from "../../components/common/Footer";
import UserLogin from "../../components/regusers/UserLogin";
import UserReg from "../../components/guestusers/UserReg";
import { Link, Outlet } from "react-router-dom";
import ShowCompanies from "../../components/guestusers/ShowCompanies";

const GuestUserHome = () => {
  const Links = [
    { link: "/user", linkdis: "Home" },
    { link: "/user/login", linkdis: "User Login" },
    { link: "/user/reg", linkdis: "User Register" },
    { link: "/reguser", linkdis: "Regiser User" },
    { link: "/employer", linkdis: "Employer" },
    { link: "/admin", linkdis: "Admin" },
  ];

  return (
    <div>
      <Header Links={Links} />
      <table class="table">
        <tbody>
          <tr>
            <td>
              <ShowCompanies />
            </td>
            <td>
              <Outlet />
            </td>
          </tr>
        </tbody>
      </table>

      <Footer />
      <br />
    </div>
  );
};

export default GuestUserHome;
