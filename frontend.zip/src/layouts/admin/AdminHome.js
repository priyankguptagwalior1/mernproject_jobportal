import React from "react";
import Header from "../../components/common/Header";
import Footer from "../../components/common/Footer";
import AdminLogin from "../../components/admin/AdminLogin";
import { Link, Outlet } from "react-router-dom";
const AdminHome = () => {
  const Links = [
    { link: "/admin", linkdis: "Home" },
    { link: "/admin/about", linkdis: "About Compnay" },
    { link: "/employer", linkdis: "Employer" },
    // { link: "/user", linkdis: "User" },
  ];
  return (
    <>
      <Header Links={Links} />
      {/* <AdminLogin /> */}
      <Outlet />
      <Footer />
      <br />
    </>
  );
};

export default AdminHome;
