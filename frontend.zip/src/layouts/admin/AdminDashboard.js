import React from "react";
import Header from "../../components/common/Header";
import Footer from "../../components/common/Footer";
import AdminLogin from "../../components/admin/AdminLogin";
import ShowEmployers from "../../components/admin/ShowEmployers";
const AdminDashboard = () => {
  const Links = [
    { link: "#", linkdis: "Dashboard" },
    { link: "#", linkdis: "Show Users" },
    { link: "/admin/showemployers", linkdis: "Show Employers" },
    { link: "#", linkdis: "Show Jobs" },
    { link: "#", linkdis: "Show Jobs Posts" },
    { link: "/admin/logout", linkdis: "Logout" },
  ];
  return (
    <div>
      <Header Links={Links} />
      {/* <AdminLogin /> */}

      <ShowEmployers />

      <Footer />
      <br />
    </div>
  );
};

export default AdminDashboard;
