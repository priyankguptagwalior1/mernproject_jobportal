import AdminRegModel from "../models/AdminRegModel.js";
import UserRegModel from "../models/UserRegModel.js";
import EmployerRegModel from "../models/EmployerRegModel.js";
import bcryptjs from "bcryptjs";
import jwt from "jsonwebtoken";

const AdminRegister = async (req, res) => {
  const { adminName, adminEmail, adminPassword, adminRPassword } = req.body;
  const data = req.body;
  console.log(data);
  if (adminName && adminEmail && adminPassword && adminRPassword) {
    if (adminPassword === adminRPassword) {
      try {
        const saltKey = await bcryptjs.genSalt(12);
        const hashPassword = await bcryptjs.hash(data.adminPassword, saltKey);
        data.adminPassword = hashPassword;
        const doc = new AdminRegModel(data);
        await doc.save();
        res.status(201).send({
          status: "Success",
          message: "Admin Record Inserted...",
          data,
        });
      } catch (err) {
        console.log(err);
        res
          .status(500)
          .send({ status: "Error", message: "Admin Unable to Reg.", err });
      }
    } else {
      res.status(200).send({
        status: "Password Issue",
        message: "Admin Password and Confirm Password dose not matched...",
      });
    }
  } else {
    res
      .status(200)
      .send({ status: "Data Issue", message: "All fields are required..." });
  }
};

const AdminLogin = async (req, res) => {
  console.log(req);
  try {
    const adminDataArr = await AdminRegModel.find({
      adminEmail: req.body.adminLoginId,
    });
    const adminData = adminDataArr[0];
    if (adminDataArr.length > 0) {
      const chkPass = await bcryptjs.compare(
        req.body.adminPassword,
        adminData.adminPassword
      );
      console.log(chkPass);
      if (chkPass) {
        const adminData1 = {
          adminName: adminData.adminName,
          adminEmail: adminData.adminEmail,
        };
        //create token
        const token = jwt.sign(
          { adminID: adminData._id, adminEmail: adminData.adminEmail },
          "myjsonwebtokenkeyforadmin",
          {
            expiresIn: "2h",
          }
        );
        // save user token
        adminData1.token = token;
        res.status(200).send({
          status: "success",
          message: "Login Success...",
          adminData1,
        });
      } else {
        res.status(200).send({
          status: "fail",
          message: "Password Not Matched...",
        });
      }
    } else {
      res.status(200).send({
        status: "fail",
        message: "admin's Email Not Found",
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send({
      status: "Error",
      message: "admin Unable to display user details",
      err,
    });
  }
};

const UserDisplay = async (req, res) => {
  try {
    console.log(req);
    const result = jwt.verify(req.token, "myjsonwebtokenkeyforadmin");
    console.log(result);
    const userData = await UserRegModel.find({});
    if (userData.length > 0) {
      res.status(200).send({
        status: "Success",
        message: "Get User Records",
        userData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "No User Found...",
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send({
      status: "Error",
      message: `Unable to display User details ${err}`,
    });
  }
};

const EmployerDisplay = async (req, res) => {
  try {
    console.log(req);
    // const result = jwt.verify(req.token, "myjsonwebtokenkeyforadmin");
    const employerData = await EmployerRegModel.find({});
    if (employerData.length > 0) {
      res.status(200).send({
        status: "Success",
        message: "Get Employer Records",
        employerData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "No Employer Found...",
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send({
      status: "Error",
      message: `Unable to display employer details ${err}`,
    });
  }
};

const EmployerSearchByStatus = async (req, res) => {
  try {
    console.log(req.params);
    const result = jwt.verify(req.token, "myjsonwebtokenkeyforadmin");
    console.log(result);
    const employerData = await EmployerRegModel.find({
      employerStatus: req.params.status,
    });
    if (employerData.length > 0) {
      res.status(200).send({
        status: "Success",
        message: `Get Employer by Status ${req.status}`,
        employerData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "No Employer Found...",
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send({
      status: "Error",
      message: `Unable to display employer details ${err}`,
    });
  }
};

const EmployerUpdateStatus = async (req, res) => {
  try {
    console.log("REQ.BODY: ", req.body);
    console.log("REQ.PARAMS.ID: ", req.params.id);
    const employerData = await EmployerRegModel.findByIdAndUpdate(
      {
        _id: req.params.id,
      },
      req.body
    );
    if (employerData) {
      res.status(200).send({
        status: "Success",
        message: "Employer Updated",
        employerData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "Employer Not Found",
      });
    }
  } catch (err) {
    console.log(err);
    res
      .status(500)
      .send({ status: "Error", message: "Unable to update Employer details" });
  }
};

export default {
  AdminRegister,
  AdminLogin,
  UserDisplay,
  EmployerDisplay,
  EmployerSearchByStatus,
  EmployerUpdateStatus,
};
