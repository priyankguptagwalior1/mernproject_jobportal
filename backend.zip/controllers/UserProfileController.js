import UserProfileModel from "../models/UserProfileModel.js";
const UserProfile = async (req, res) => {
  try {
    const doc = new UserProfileModel(req.body);
    await doc.save();
    res.status(201).send({
      status: "Success",
      message: "User Profile Inserted...",
      data: req.body,
    });
  } catch (err) {
    console.log(err);
    res.status(500).send({ status: "Error", message: "Unable to Reg.", err });
  }
};

export default { UserProfile };
