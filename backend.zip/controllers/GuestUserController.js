import EmployerRegModel from "../models/EmployerRegModel.js";
import JobPostModel from "../models/JobPostModel.js";
const EmployerDisplay = async (req, res) => {
  try {
    console.log(req);
    const employerData = await EmployerRegModel.find({});
    if (employerData.length > 0) {
      res.status(200).send({
        status: "Success",
        message: "Get Employer Records",
        employerData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "No Employer Found...",
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send({
      status: "Error",
      message: `Unable to display employer details ${err}`,
    });
  }
};

const JobsDisplay = async (req, res) => {
  try {
    console.log(req);
    const JobsData = await JobPostModel.find({});
    if (JobsData.length > 0) {
      res.status(200).send({
        status: "Success",
        message: "Get JobsData Records",
        JobsData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "No JobsData Found...",
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send({
      status: "Error",
      message: `Unable to display JobsData details ${err}`,
    });
  }
};

export default {
  EmployerDisplay,
  JobsDisplay,
};
