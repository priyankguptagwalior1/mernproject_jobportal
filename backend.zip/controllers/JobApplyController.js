const JobApplyController = () => {};

export default JobApplyController;
