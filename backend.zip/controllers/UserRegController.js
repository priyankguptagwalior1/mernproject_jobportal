import UserRegModel from "../models/UserRegModel.js";
import bcryptjs from "bcryptjs";
import jwt from "jsonwebtoken";
const UserRegister = async (req, res) => {
  const { userName, userEmail, userMobile, userPassword, userRPassword } =
    req.body;
  const data = req.body;
  console.log(data);
  if (userName && userEmail && userMobile && userPassword && userRPassword) {
    if (userPassword === userRPassword) {
      try {
        const saltKey = await bcryptjs.genSalt(12);
        const hashPassword = await bcryptjs.hash(data.userPassword, saltKey);
        data.userPassword = hashPassword;
        const doc = new UserRegModel(data);
        await doc.save();
        res.status(201).send({
          status: "Success",
          message: "Record Inserted...",
          data,
        });
      } catch (err) {
        console.log(err);
        res
          .status(500)
          .send({ status: "Error", message: "Unable to Reg.", err });
      }
    } else {
      res.status(200).send({
        status: "Password Issue",
        message: "Password and Confirm Password dose not matched...",
      });
    }
  } else {
    res
      .status(200)
      .send({ status: "Data Issue", message: "All fields are required..." });
  }
};

const UserLogin = async (req, res) => {
  console.log(req);
  try {
    const userDataArr = await UserRegModel.find({
      userEmail: req.body.userEmail,
    });
    const userData = userDataArr[0];
    if (userDataArr.length > 0) {
      console.log(req.body);
      console.log(userData);
      console.log(typeof userData.userPassword);
      console.log(typeof req.body.userPassword);
      const chkPass = await bcryptjs.compare(
        req.body.userPassword,
        userData.userPassword
      );
      console.log(chkPass);
      if (chkPass) {
        const userData1 = {
          userName: userData.userName,
          userEmail: userData.userEmail,
          userMobile: userData.userMobile,
          userStatus: userData.userStatus,
        };
        if (userData.userStatus === "Active") {
          //create token

          const token = jwt.sign(
            { userID: userData._id, userEmail: userData.userEmail },
            "myjsonwebtokenkeyforuser",
            {
              expiresIn: "2h",
            }
          );
          // save user token
          userData1.token = token;
          res.status(200).send({
            status: "success",
            message: "Login Success...",
            userData1,
          });
        } else {
          res.status(200).send({
            status: "success",
            message: "Your account not approved...",
          });
        }
      } else {
        res.status(200).send({
          status: "Fail",
          message: "Password Not Matched...",
        });
      }
      // res.status(200).send({
      //   status: "Success",
      //   message: "Get User Record",
      //   userData,
      // });
    } else {
      res.status(200).send({
        status: "Success",
        message: "User's Email Not Found",
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send({
      status: "Error",
      message: "Unable to display user details",
      err,
    });
  }
};

const UserSearchByID = async (req, res) => {
  try {
    const userData = await UserRegModel.find({ _id: req.params.id });
    if (userData.length > 0) {
      res.status(200).send({
        status: "Success",
        message: "Get User Record",
        userData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "User Not Found",
      });
    }
  } catch (err) {
    console.log(err);
    res
      .status(500)
      .send({ status: "Error", message: "Unable to display user details" });
  }
};

const UserDashbard = async (req, res) => {
  try {
    const result = jwt.verify(req.token, "myjsonwebtokenkeyforuser");
    console.log("RESULT", result);

    const userData = await UserRegModel.find({ userEmail: result.userEmail });
    if (userData.length > 0) {
      res.status(200).send({
        status: "Success",
        message: "Get User Record",
        userData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "User Not Found",
      });
    }
  } catch (err) {
    console.log(err);
    res
      .status(500)
      .send({ status: "Error", message: "Unable to display user details" });
  }
};

const UserDeleteAll = async (req, res) => {
  try {
    const userData = await UserRegModel.deleteMany({});
    if (userData) {
      res.status(200).send({
        status: "Success",
        message: "Delete All User",
        userData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "No User found",
      });
    }
  } catch (err) {
    console.log(err);
    res
      .status(500)
      .send({ status: "Error", message: "Unable to delete user details" });
  }
};

const UserDeleteByID = async (req, res) => {
  try {
    const userData = await UserRegModel.findByIdAndDelete({
      _id: req.params.id,
    });
    if (userData) {
      res.status(200).send({
        status: "Success",
        message: "This User Deleted",
        userData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "Student Not Found",
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send({
      status: "Error",
      message: "Unable to delete user details by ID",
    });
  }
};

const UserUpdateByID = async (req, res) => {
  try {
    console.log(req.body);
    console.log(req.params.id);
    const userData = await UserRegModel.findByIdAndUpdate(
      {
        _id: req.params.id,
      },
      req.body
    );
    if (userData) {
      res.status(200).send({
        status: "Success",
        message: "User Updated",
        userData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "User Not Found",
      });
    }
  } catch (err) {
    console.log(err);
    res
      .status(500)
      .send({ status: "Error", message: "Unable to update student details" });
  }
};
const UserForgetPassword = async (req, res) => {
  console.log(req.body);
  res
    .status(200)
    .send({ status: "Success", message: "Passwrod sent in-progress" });
};
export default {
  UserRegister,
  UserLogin,
  UserDashbard,
  UserSearchByID,
  UserDeleteAll,
  UserDeleteByID,
  UserUpdateByID,
  UserForgetPassword,
};
