const EmployerProfileController = () => {};

export default EmployerProfileController;
