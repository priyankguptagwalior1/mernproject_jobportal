import EmployerRegModel from "../models/EmployerRegModel.js";
import bcryptjs from "bcryptjs";
import jwt from "jsonwebtoken";

const EmployerRegister = async (req, res) => {
  const {
    employerName,
    employerEmail,
    employerMobile,
    employerWebsite,
    employerPassword,
    employerRPassword,
  } = req.body;
  const data = req.body;
  console.log(data);
  if (
    employerName &&
    employerEmail &&
    employerMobile &&
    employerWebsite &&
    employerPassword &&
    employerRPassword
  ) {
    if (employerPassword === employerRPassword) {
      try {
        const saltKey = await bcryptjs.genSalt(12);
        const hashPassword = await bcryptjs.hash(
          data.employerPassword,
          saltKey
        );
        data.employerPassword = hashPassword;
        const doc = new EmployerRegModel(data);
        await doc.save();
        res.status(201).send({
          status: "Success",
          message: "Record Inserted...",
          data,
        });
      } catch (err) {
        console.log(err);
        res
          .status(500)
          .send({ status: "Error", message: "Unable to Reg.", err });
      }
    } else {
      res.status(200).send({
        status: "Password Issue",
        message: "Password and Confirm Password dose not matched...",
      });
    }
  } else {
    res
      .status(200)
      .send({ status: "Data Issue", message: "All fields are required..." });
  }
};

const EmployerLogin = async (req, res) => {
  console.log(req);
  try {
    const employerDataArr = await EmployerRegModel.find({
      employerEmail: req.body.employerEmail,
    });
    const employerData = employerDataArr[0];
    if (employerDataArr.length > 0) {
      const chkPass = await bcryptjs.compare(
        req.body.employerPassword,
        employerData.employerPassword
      );
      console.log(chkPass);
      if (chkPass) {
        const employerData1 = {
          employerName: employerData.employerName,
          employerEmail: employerData.employerEmail,
          employerMobile: employerData.employerMobile,
          employerWebsite: employerData.employerWebsite,
          employerStatus: employerData.employerStatus,
        };
        if (employerData.employerStatus === "Active") {
          //create token

          const token = jwt.sign(
            {
              employerID: employerData._id,
              employerEmail: employerData.employerEmail,
            },
            "myjsonwebtokenkeyforuser",
            {
              expiresIn: "2h",
            }
          );
          // save employer token
          employerData1.token = token;
          res.status(200).send({
            status: "success",
            message: "Login Success...",
            employerData1,
          });
        } else {
          res.status(200).send({
            status: "success",
            message: "Your account not approved...",
          });
        }
      } else {
        res.status(200).send({
          status: "Fail",
          message: "Password Not Matched...",
        });
      }
    } else {
      res.status(200).send({
        status: "Success",
        message: "employer's Email Not Found",
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send({
      status: "Error",
      message: "Unable to display employer details",
      err,
    });
  }
};

const EmployerDisplay = async (req, res) => {
  try {
    // console.log(req);
    // const result = jwt.verify(req.token, "myjsonwebtokenkeyforuser");
    // console.log(result);
    const employerData = await EmployerRegModel.find({});
    if (employerData.length > 0) {
      res.status(200).send({
        status: "Success",
        message: "Get Employer Records",
        employerData,
      });
    } else {
      res.status(200).send({
        status: "Success",
        message: "No Employer Found...",
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).send({
      status: "Error",
      message: "Unable to display emaplyer details",
    });
  }
};

export default {
  EmployerRegister,
  EmployerLogin,
  EmployerDisplay,
};
