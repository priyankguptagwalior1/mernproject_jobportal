import mongoose from "mongoose";
const UserProfileSchema = new mongoose.Schema({
  userID: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "userreg",
    required: [true, "User ID is Required"],
    unique: true,
    trim: true,
  },
  userSkills: {
    type: String,
    required: [true, "User Name is Required"],
    trim: true,
  },
  userExp: {
    type: String,
    required: ["true", "User Exp is Required"],
    enum: ["Yes", "No"],
    trim: true,
  },
  userExpDetails: {
    type: String,
    required: false,
    trim: true,
  },
  userOtherInfo: {
    type: String,
    required: false,
    trim: true,
  },
});

const UserProfileModel = mongoose.model("userprofile", UserProfileSchema);

export default UserProfileModel;
