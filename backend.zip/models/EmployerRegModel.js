import mongoose from "mongoose";
const employerRegSchema = new mongoose.Schema({
  employerName: {
    type: String,
    required: [true, "employer Name is Required"],
    // unique: true,
    trim: true,
  },
  employerEmail: {
    type: String,
    required: [true, "employer Email is Required"],
    // unique: true,
    trim: true,
  },
  employerMobile: {
    type: Number,
    required: [true, "employer Mobile Number is Required"],
    // unique: true,
    trim: true,
  },
  employerWebsite: {
    type: String,
    required: [true, "employer Website is Required"],
    // unique: true,
    trim: true,
  },
  employerPassword: {
    type: String,
    required: [true, "employer Password is Required Field"],
    trim: true,
    minlength: 6,
    maxlength: 100,
  },
  employerStatus: {
    type: String,
    required: [true, "employer Status is Required Field"],
    trim: true,
    default: "Pending",
  },
});

const EmployerRegModel = mongoose.model("employerreg", employerRegSchema);

export default EmployerRegModel;
