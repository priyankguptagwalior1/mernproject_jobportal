import mongoose from "mongoose";
const jobApplySchema = new mongoose.Schema({
  jobPostID: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "jobpost",
    required: [true, "jobPostID ID is Required"],
    trim: true,
  },
  userID: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "userreg",
    required: [true, "userID ID is Required"],
    trim: true,
  },
  jobLoc: {
    type: String,
    required: [true, "jobLoc is Required"],
    trim: true,
  },
  jobMode: {
    type: String,
    required: [true, "jobMode is Required"],
    trim: true,
  },

  jobType: {
    type: String,
    required: [true, "jobType is Required"],
    trim: true,
  },
  status: {
    type: String,
    required: [true, "status is Required"],
    default: "Active",
    trim: true,
  },
});
const JobApplyModel = mongoose.model("jobapply", jobApplySchema);

export default JobApplyModel;
