import mongoose from "mongoose";
const adminRegSchema = new mongoose.Schema({
  adminName: {
    type: String,
    required: [true, "Admin Name is Required"],
    trim: true,
  },
  adminEmail: {
    type: String,
    required: [true, "admin Email is Required"],
    unique: true,
    trim: true,
  },
  adminPassword: {
    type: String,
    required: [true, "admin Password is Required Field"],
    trim: true,
    minlength: 6,
    maxlength: 100,
  },
});

const AdminRegModel = mongoose.model("adminreg", adminRegSchema);

export default AdminRegModel;
