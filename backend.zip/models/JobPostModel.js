import mongoose from "mongoose";
const jobPostSchema = new mongoose.Schema({
  employerID: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "employerreg",
    required: [true, "Employer ID is Required"],
    trim: true,
  },
  jobTitle: {
    type: String,
    required: [true, "Job Title is Required"],
    trim: true,
  },
  jobDesc: {
    type: String,
    required: [true, "jobDesc is Required"],
    trim: true,
  },
  jobPackage: {
    type: String,
    required: [true, "jobPackage is Required"],
    trim: true,
  },
  jobSkills: {
    type: String,
    required: [true, "jobSkills is Required"],
    trim: true,
  },
  jobQuali: {
    type: String,
    required: [true, "jobQuali is Required"],
    trim: true,
  },

  jobLocs: {
    type: String,
    required: [true, "jobLoc is Required"],
    // enum: ["New Delhi", "Mumbai", "Pune"],
    trim: true,
  },
  jobModes: {
    type: String,
    required: [true, "jobMode is Required"],
    // enum: ["WFO", "WFH", "Hybrid"],
    trim: true,
  },

  jobTypes: {
    type: String,
    required: [true, "jobType is Required"],
    // enum: ["Full Time", "Part Time"],
    trim: true,
  },

  jobOpenDate: {
    type: Date,
    required: [true, "jobOpenDate is Required"],
    trim: true,
  },

  jobCloseDate: {
    type: String,
    required: [true, "jobCloseDate is Required"],
    trim: true,
  },
  jobStatus: {
    type: String,
    required: [true, "jobStatus is Required Field"],
    trim: true,
    default: "Open",
  },
});

const JobPostModel = mongoose.model("jobpost", jobPostSchema);

export default JobPostModel;
