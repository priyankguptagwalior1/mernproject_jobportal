import express from "express";
const router = express.Router();
import JobApplyController from "../controllers/JobApplyController.js";

// Public Routes
export default router;
