import express from "express";
const router = express.Router();
import UserProfileController from "../controllers/UserProfileController.js";
router.post("/register", UserProfileController.UserProfile);
// router.get("/display", UserRegController.UserDisplay);
// router.get("/display/:id", UserRegController.UserSearchByID);
// router.delete("/delete", UserRegController.UserDeleteAll);
// router.delete("/delete/:id", UserRegController.UserDeleteByID);
// router.put("/update/:id", UserRegController.UserUpdateByID);

// Public Routes
export default router;
