import express from "express";
const router = express.Router();
// import JobPostController from "../controllers/JobPostController.js";

// Public Routes
export default router;
