import express from "express";
const router = express.Router();
import UserRegController from "../controllers/UserRegController.js";
// import test from "../controllers/middelwares/middelware.js";
const userToken = (req, res, next) => {
  const myToken = req.headers["authorization"].split(" ")[1];
  console.log("...............", myToken);
  if (!myToken) {
    res.status(500).send({
      status: "Fail",
      message: "Toekn Not Found...",
    });
  } else {
    req.token = myToken;
    next();
  }
};

// const adminToken = (req, res, next) => {
//   const myToken = req.headers["authorization"].split(" ")[1];
//   console.log("...............", myToken);
//   if (!myToken) {
//     res.status(500).send({
//       status: "Fail",
//       message: "Toekn Not Found...",
//     });
//   } else {
//     req.token = myToken;
//     next();
//   }
// };

// Public Routes
router.post("/register", UserRegController.UserRegister);
router.post("/login", UserRegController.UserLogin);
router.post("/forgetpassword", UserRegController.UserForgetPassword);

// Private Routes
// router.get("/display", adminToken, UserRegController.UserDisplay);

router.get("/userdashboard", userToken, UserRegController.UserDashbard);

router.get("/display/:id", UserRegController.UserSearchByID);
router.delete("/delete", UserRegController.UserDeleteAll);
router.delete("/delete/:id", UserRegController.UserDeleteByID);
router.put("/update/:id", UserRegController.UserUpdateByID);

export default router;
