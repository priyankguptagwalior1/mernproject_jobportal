import express from "express";
const router = express.Router();
import AdminRegController from "../controllers/AdminRegController.js";
const adminToken = (req, res, next) => {
  const myToken = req.headers["authorization"].split(" ")[1];
  console.log("...............", myToken);
  if (!myToken) {
    res.status(500).send({
      status: "Fail",
      message: "Toekn Not Found...",
    });
  } else {
    req.token = myToken;
    next();
  }
};

// Public Routes
// router.post("/register", AdminRegController.AdminRegister);
router.post("/login", AdminRegController.AdminLogin);

// Private Routes
router.get("/userdisplay", adminToken, AdminRegController.UserDisplay);

router.get("/employerdisplay", AdminRegController.EmployerDisplay);
router.get("/employerupdate", AdminRegController.EmployerUpdateStatus);

router.get(
  "/employerdisplaybystatus/:status",
  adminToken,
  AdminRegController.EmployerSearchByStatus
);

router.put(
  "/employerupdatestatus/:id",
  adminToken,
  AdminRegController.EmployerUpdateStatus
);

// router.get("/userdashboard", userToken, UserRegController.UserDashbard);

// router.get("/display/:id", UserRegController.UserSearchByID);
// router.delete("/delete", UserRegController.UserDeleteAll);
// router.delete("/delete/:id", UserRegController.UserDeleteByID);
// router.put("/update/:id", UserRegController.UserUpdateByID);

export default router;
