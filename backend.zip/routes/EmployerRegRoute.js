import express from "express";
const router = express.Router();
import EmployerRegController from "../controllers/EmployerRegController.js";
// import JobPostController from "../controllers/JobPostController.js";

// Public Routes
router.post("/register", EmployerRegController.EmployerRegister);
router.post("/login", EmployerRegController.EmployerLogin);
router.get("/showallcompanies", EmployerRegController.EmployerDisplay);

// router.post("/forgetpassword", UserRegController.UserForgetPassword);

// Private Route
// router.post("/jobpost", JobPostController.JobPostRegController);

export default router;
