import express from "express";
const router = express.Router();
import EmployerProfileController from "../controllers/EmployerProfileController.js";

// Public Routes
export default router;
