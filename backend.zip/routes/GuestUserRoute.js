import express from "express";
const router = express.Router();
import GuestUserController from "../controllers/GuestUserController.js";

router.get("/employerdisplay", GuestUserController.EmployerDisplay);
router.get("/jobsdisplay", GuestUserController.JobsDisplay);

export default router;
